import storage from './storage';
export default storage;
