let users_id = "123344";

function set_users_id(data) {
  users_id = data;
}

function get_users_id() {
  return users_id;
}
