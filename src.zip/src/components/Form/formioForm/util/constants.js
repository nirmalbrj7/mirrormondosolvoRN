export const ErrorTypes = {
  FieldValueError: 'FieldValueError',
  FormFetchError: 'FormFetchError',
  FormLoadError: 'FormLoadError',
  SubmissionError: 'SubmissionError',
  VieldValidationError: 'VieldValidationError',
};
