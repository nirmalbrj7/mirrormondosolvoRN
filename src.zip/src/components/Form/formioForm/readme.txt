This section of a program is a copy of the following library
https://github.com/formio/react-native-formio
that I've adopted, integrated and modified to use in this project.


At the moment of writing this, there is no functional
lib for working with form.io forms on react-native.

The only thing I have - is this repository. It's probably, dead. Last commit was
about 5 months ago and readme says that:
THIS LIBRARY IS PRE-ALPHA AND NOT READY FOR USE IN ANY FORM.

Thus I had to copy the sources of it to my project and try to make them work.
(Which I did)

Despite many good working parts, this code is really crappy and wicked.
I've tried to fix some parts and add some comments that make things clear.
But still...

So, if you, Another Developer From Future read this. I wish you good luck and
patience with figuring this out! ;)
