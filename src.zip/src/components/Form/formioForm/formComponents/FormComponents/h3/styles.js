import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  header3: {
    fontSize: 22,
    margin: 10,
    lineHeight: 28,
    letterSpacing: 0.35,
  }
});

export default styles;
