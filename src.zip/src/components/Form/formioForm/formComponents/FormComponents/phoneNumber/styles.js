import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  phoneNumber: {

  }
});

export default styles;
