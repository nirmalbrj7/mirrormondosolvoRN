import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  filedset: {
    flex: 1,
    flexDirection: 'column',
    padding: 0,
  },
});

export default styles;
