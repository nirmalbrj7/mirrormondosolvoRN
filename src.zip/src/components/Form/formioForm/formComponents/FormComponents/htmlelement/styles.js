import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  content: {
    flex: 1,
    marginHorizontal:5,
    marginBottom:2
  }
});

export default styles;
