
import Datetime from '../datetime/Datetime';
export default class Day extends Datetime {
}
