import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  email: {
    borderBottomWidth: 1,
  }
});

export default styles;
