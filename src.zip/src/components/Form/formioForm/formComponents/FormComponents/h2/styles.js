import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  header2: {
    fontSize: 28,
    margin: 10,
    lineHeight: 34,
    letterSpacing: 0.36,
  }
});

export default styles;
