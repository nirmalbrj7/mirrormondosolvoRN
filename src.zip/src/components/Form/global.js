const global={}
global.currentCardNumber='1111';
export default global;