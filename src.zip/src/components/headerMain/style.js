import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  buttonContainerNoPadding: {
    padding: 0,
    backgroundColor:'#fff'
  },
});

export default styles;
