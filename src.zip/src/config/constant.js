export const AppVersion = '0.0.7';
export const AppName = 'BC Forms';


//Social
export const Youtube = 'https://www.youtube.com/user/BuildChange';
export const Facebook = 'https://www.facebook.com/BuildChange';
export const Twitter = 'https://www.facebook.com/BuildChange';




