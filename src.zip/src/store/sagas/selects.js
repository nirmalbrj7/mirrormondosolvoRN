 
export const takeCurrentSubmissionFromState = state => state.submission;
export const takeCurrentFormIdFromState = state => state.form.firebaseFormId;
export const takeCurrentFormDefinitionFromState = state => state.form.form;