import ActionTypes from './actionTypes';

export default function fetchFormsList() {
  return {
    type: ActionTypes.FETCH_FORMS_LIST,
  };
}
