import React from 'react';
import {Text} from 'react-native';
const AddRecord=(props)=>{
return(
    <Text>Add Record</Text>
);
}
export default AddRecord;