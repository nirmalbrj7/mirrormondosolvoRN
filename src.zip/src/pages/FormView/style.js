import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  textContainer: {
    alignSelf: 'flex-start',
    marginHorizontal: 10,
  },
});

export default styles;
