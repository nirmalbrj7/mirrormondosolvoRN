import React,{useEffect} from 'react';

const Logout=()=>{
    useEffect(() => { alert('sssssssss') }, [])
}
export default Logout;