export const AppName="Data Collection App";
export const AppVersion="0.0.1";